# Desktop and mobile releases

## Windows

Build the desktop app and installer on Windows:

```powershell
.\scripts\build-desktop.ps1 -Target windows -Installer
```

The script uses Inno Setup 6 when it is installed and produces `dist/installer/TrimPlaylist-Setup.exe`. To build a release while a development copy is open, use a separate output directory:

```powershell
.\scripts\build-desktop.ps1 -Target windows -Installer -DistPath dist/release-build -WorkPath build/release-build
```

### Windows antivirus and SmartScreen

The Windows executable bundles Python, FFmpeg, and a local web server. Unsigned PyInstaller applications can trigger generic antivirus or SmartScreen warnings even when the source is clean. The release build disables UPX packing to reduce false positives, but the reliable solution is to sign both the app and installer with a trusted code-signing certificate.

Import your certificate into `Cert:\CurrentUser\My`, then build with its thumbprint:

```powershell
.\scripts\build-desktop.ps1 -Target windows -Installer -CertificateThumbprint YOUR_CERTIFICATE_THUMBPRINT
```

This signs the main application before packaging and the final installer after packaging. Do not distribute a build that has been detected as malware until it has been scanned and the detection is resolved or reported as a false positive to the detecting vendor.

## Linux and macOS

The desktop app uses native Python and pywebview libraries, so each package must be built on its target operating system:

```powershell
pwsh ./scripts/build-desktop.ps1 -Target linux
pwsh ./scripts/build-desktop.ps1 -Target macos
```

Linux packaging can then use AppImage, Flatpak, or a distribution package. macOS packaging and notarization require a Mac, Xcode, and an Apple signing identity.

## Android and iOS

The current application is a local Python desktop server with yt-dlp and FFmpeg. It cannot be wrapped into a working APK or IPA because Android and iOS do not provide that desktop runtime. A mobile release needs a separate mobile client and either a hosted download/stream service or a redesigned device-native downloader.

An Android APK can be signed on Windows, Linux, or macOS after that mobile client exists. An iOS IPA must be signed and built on macOS with Xcode and an Apple Developer account.

# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
import sys

from PyInstaller.utils.hooks import collect_data_files, collect_submodules

ROOT = Path(SPECPATH)
WINDOWS_ICON = ROOT / "denia.ico"
import runpy
runpy.run_path(str(ROOT / "scripts" / "package_extension.py"))["package_extension"](ROOT)

datas = [(str(ROOT / "player"), "player")]
if (ROOT / "denia.ico").is_file():
    datas.append((str(ROOT / "denia.ico"), "."))
datas += collect_data_files("imageio_ffmpeg")

a = Analysis(
    ["pc/app/trim_playlist_app.py"],
    pathex=[str(ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=["imageio_ffmpeg", "webview"] + (["clr"] if sys.platform == "win32" else []) + collect_submodules("yt_dlp"),
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="TrimPlaylist",
    icon=str(WINDOWS_ICON) if sys.platform == "win32" and WINDOWS_ICON.is_file() else None,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name="TrimPlaylist",
)
